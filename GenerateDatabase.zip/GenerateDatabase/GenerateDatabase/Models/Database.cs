﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenerateDatabase.Models
{
    /// <summary>
    /// 数据库
    /// </summary>
    /// <remarks>data base</remarks>
    public class Database
    {
        /// <summary>
        /// * 数据表名
        /// </summary>
        /// <remark>允许Null值：否 Length:10</remark>
        public string TableName { get; set; }
        public List<TableAttr> TAbleAttrList { get; set; }
    }
    public class TableAttr
    {
        public string Name { get; set; }
        public bool IsNullable { get; set; }
        public string Type { get; set; }
        public int Length { get; set; }
        public string Notes { get; set; }
    }
}
