﻿using System.Configuration;

namespace GenerateDatabase
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.create = new System.Windows.Forms.Button();
            this.messages = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.path = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.nameSpace = new System.Windows.Forms.TextBox();
            this.server = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.userid = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.pwd = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.database = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // create
            // 
            this.create.Location = new System.Drawing.Point(68, 393);
            this.create.Name = "create";
            this.create.Size = new System.Drawing.Size(75, 23);
            this.create.TabIndex = 0;
            this.create.Text = "生  成";
            this.create.UseVisualStyleBackColor = true;
            this.create.Click += new System.EventHandler(this.create_Click);
            // 
            // messages
            // 
            this.messages.FormattingEnabled = true;
            this.messages.ItemHeight = 17;
            this.messages.Location = new System.Drawing.Point(68, 146);
            this.messages.Name = "messages";
            this.messages.Size = new System.Drawing.Size(654, 225);
            this.messages.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(68, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "生成目录";
            // 
            // path
            // 
            this.path.Location = new System.Drawing.Point(127, 65);
            this.path.Name = "path";
            this.path.Size = new System.Drawing.Size(595, 23);
            this.path.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(68, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "命名空间";
            // 
            // nameSpace
            // 
            this.nameSpace.Location = new System.Drawing.Point(127, 102);
            this.nameSpace.Name = "nameSpace";
            this.nameSpace.Size = new System.Drawing.Size(595, 23);
            this.nameSpace.TabIndex = 3;
            // 
            // server
            // 
            this.server.Location = new System.Drawing.Point(127, 27);
            this.server.Name = "server";
            this.server.Size = new System.Drawing.Size(94, 23);
            this.server.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(79, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Server";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(230, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 17);
            this.label5.TabIndex = 2;
            this.label5.Text = "User Id";
            // 
            // userid
            // 
            this.userid.Location = new System.Drawing.Point(283, 27);
            this.userid.Name = "userid";
            this.userid.Size = new System.Drawing.Size(94, 23);
            this.userid.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(388, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "Password";
            // 
            // pwd
            // 
            this.pwd.Location = new System.Drawing.Point(455, 27);
            this.pwd.Name = "pwd";
            this.pwd.Size = new System.Drawing.Size(94, 23);
            this.pwd.TabIndex = 4;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(562, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 17);
            this.label7.TabIndex = 2;
            this.label7.Text = "Database";
            // 
            // database
            // 
            this.database.Location = new System.Drawing.Point(628, 27);
            this.database.Name = "database";
            this.database.Size = new System.Drawing.Size(94, 23);
            this.database.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.database);
            this.Controls.Add(this.pwd);
            this.Controls.Add(this.userid);
            this.Controls.Add(this.server);
            this.Controls.Add(this.nameSpace);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.path);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.messages);
            this.Controls.Add(this.create);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "生成实体（Sql Server）";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button create;
        private System.Windows.Forms.ListBox messages;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox path;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox nameSpace;
        private System.Windows.Forms.TextBox sqlConnecion;
        private System.Windows.Forms.TextBox server;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox userid;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox pwd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox database;
    }
}

