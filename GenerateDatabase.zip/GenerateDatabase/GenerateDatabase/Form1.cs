﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using GenerateDatabase.Models;
using System.IO;
using System.Configuration;
using System.Diagnostics;

namespace GenerateDatabase
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            var appSets = ConfigurationManager.AppSettings;
            //sqlConnection.Text = appSets["sqlConnecion"] ?? "server=;user id=;pwd=;database=";
            server.Text = appSets["server"];
            userid.Text = appSets["user id"];
            pwd.Text = appSets["pwd"];
            database.Text = appSets["database"];
            path.Text = appSets["path"] ?? @"C:\GenerateEntities";
            nameSpace.Text = appSets["namespace"] ?? "System";
        }
        private void create_Click(object sender, EventArgs e)
        {
            create.Text = "生成中..";
            create.Enabled = false;


            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            List<Database> databases = GetDatabases();
            CreateEntities(databases, path.Text, nameSpace.Text);

            stopwatch.Stop();

            messages.Items.Insert(0, "");
            messages.Items.Insert(0, "----------生成完成，运行时间：" + stopwatch.ElapsedMilliseconds + "毫秒，时间："+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+"----------");

            create.Text = "生  成";
            create.Enabled = true;
        }


        /// <summary>
        /// 生成实体
        /// </summary>
        /// <param name="databases"></param>
        /// <param name="root"></param>
        /// <param name="namespaces"></param>
        public void CreateEntities(List<Database> databases, string root, string namespaces)
        {

            foreach (var item in databases)
            {
                string path = root + item.TableName;

                messages.Items.Add(item.TableName);

                if (File.Exists(path))
                {
                    File.Delete(path);
                }

                StringBuilder sb = new StringBuilder();
                sb.AppendFormat(
@"using System;

namespace {0}
{{
    /// <summary>
    /// {1}
    /// </summary>
    public class {2}
    {{
", namespaces, "", item.TableName);

                foreach (var attr in item.TAbleAttrList)
                {

                    string type = GetDatabaseType(attr.Type, attr.IsNullable, attr.Length);

                    sb.AppendFormat(
@"        /// <summary>
        /// {0}{1}
        /// </summary>
        /// <remark>允许Null值：{2} Length:{3}</remark>
        public {4} {5} {{ get; set; }}
", attr.IsNullable ? null : "* ", attr.Notes, attr.IsNullable ? "是" : "否", attr.Length, type, attr.Name);

                }

                sb.AppendLine("    }");
                sb.Append("}");

                File.WriteAllText(path + ".cs", sb.ToString());
            }

        }


        /// <summary>
        /// 获取数据库的所有表
        /// </summary>
        /// <returns></returns>
        List<Database> GetDatabases()
        {

            try
            {
                string sqlConnection = string.Format("server={0};user id={1};pwd={2};database={3}", server.Text, userid.Text, pwd.Text, database.Text);

                var connection = new SqlConnection(sqlConnection);
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"select 
	                                    tableName.name as tableName,
	                                    mytable.NAME,                    
	                                    mytable.ISNULLABLE,            
	                                    mytable.PREC,                    
	                                    mytable.[TYPE],
                                        ISNULL(mytable.NOTES, '') as NOTES
                                    from 
                                    (
	                                    (SELECT NAME FROM SYSOBJECTS WHERE TYPE='U') as tableName
	                                    join 
	                                    (Select
	                                    SCOL.Id, 
	                                    SCOL.NAME,                    
	                                    SCOL.ISNULLABLE,            
	                                    ISNULL(SCOL.PREC, 0) as PREC,                    
	                                    STYPE.NAME AS [TYPE] ,        
	                                    (SELECT SYS.EXTENDED_PROPERTIES.VALUE FROM SYSCOLUMNS   
	                                    INNER JOIN SYS.EXTENDED_PROPERTIES ON SYSCOLUMNS.ID = SYS.EXTENDED_PROPERTIES.MAJOR_ID   
	                                    AND SYSCOLUMNS.COLID = SYS.EXTENDED_PROPERTIES.MINOR_ID   
	                                    INNER JOIN SYSOBJECTS ON SYSCOLUMNS.ID = SYSOBJECTS.ID   
	                                    WHERE SYSOBJECTS.NAME = SO.NAME AND SYSCOLUMNS.NAME = SCOL.NAME) AS NOTES   

	                                    from SYSCOLUMNS AS SCOL
	                                    LEFT JOIN SYSOBJECTS SO ON SO.ID=SCOL.ID 
	                                    LEFT JOIN SYSTYPES AS STYPE ON STYPE.xtype=SCOL.xtype
	                                    Where 
	                                    --SCOL.ID=OBJECT_ID('checkin')
	                                    --AND 
	                                    STYPE.NAME<>'SYSNAME') as mytable
	                                    on OBJECT_ID(tableName.name) = mytable.Id
                                    )";

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = command;

                DataTable pubsSet = new DataTable();
                da.Fill(pubsSet);

                List<Database> allDatebase = new List<Database>();
                foreach (DataRow row in pubsSet.Rows)
                {
                    int index = 0;
                    string tableName = row[index].ToString(); ;

                    if (allDatebase.Any(p => p.TableName == tableName))
                    {
                        Database database = allDatebase.Where(p => p.TableName == tableName).First();

                        var tableAttr = new TableAttr();
                        tableAttr.Name = row[++index].ToString();
                        tableAttr.IsNullable = Convert.ToBoolean(row[++index]);
                        tableAttr.Length = Convert.ToInt16(row[++index]);
                        tableAttr.Type = row[++index].ToString();
                        tableAttr.Notes = row[++index].ToString();

                        database.TAbleAttrList.Add(tableAttr);
                    }
                    else
                    {
                        Database database = new Database();
                        database.TableName = tableName;

                        List<TableAttr> tableAttrs = new List<TableAttr>();
                        var tableAttr = new TableAttr();
                        tableAttr.Name = row[++index].ToString();
                        tableAttr.IsNullable = Convert.ToBoolean(row[++index]);
                        tableAttr.Length = Convert.ToInt16(row[++index]);
                        tableAttr.Type = row[++index].ToString();
                        tableAttr.Notes = row[++index].ToString();
                        tableAttrs.Add(tableAttr);

                        database.TAbleAttrList = tableAttrs;
                        allDatebase.Add(database);
                    }
                }

                connection.Close();

                return allDatebase;
            }
            catch (Exception ex)
            {
                messages.Items.Add("连接数据库发生异常：");
                messages.Items.Add(ex.Message);
            }

            return null;
        }

        /// <summary>
        /// 获取数据库类型
        /// </summary>
        /// <param name="type"></param>
        /// <param name="isNullable"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        string GetDatabaseType(string type, bool isNullable, int length)
        {
            string nullable = isNullable ? "?" : "";
            switch (type)
            {
                case "int": return "int" + nullable;
                case "money":
                case "decimal": return "decimal" + nullable;
                case "float": return "float" + nullable;
                case "datetime":
                case "datetime2":
                case "date": return "DateTime" + nullable;
                case "uniqueidentifier": return "Guid" + nullable;
                case "bit": return "bool" + nullable;
                default: return "string";
            }
        }

    }
}
